const converter = require("../Utils/converter");

module.exports = {
    mapDocument: function (src) {

        // Generic parts of the TrainComposition message
        let dst = this.createRoot();       
        this.addSoapHeaderAndBody(dst);
        // this.addimportTripRequest(dst);
        // this.addrailml(dst);
        // this.addinfrastructure(src,dst);
        // this.addrollingstock(src,dst);
        // this.addtimetable(dst);
        // this.addoperatingPeriods(src,dst);
        // this.addcategories(src,dst);
        // this.addtrainParts(src,dst);
        // this.addtrain(src,dst);

        return dst;
    },
    createRoot: function () {
        let root = {
            "soapenv:Envelope": {},
        }
        root["soapenv:Envelope"]["@_xmlns:soapenv"] = "http://schemas.xmlsoap.org/soap/envelope/";
        root["soapenv:Envelope"]["@_xmlns:ns"] = "http://www.ivu.de/IVU.rail/VehicleWorkingImport/2.0/";
        root["soapenv:Envelope"]["@_xmlns:ns1"] = "http://www.ivu.de/IVU.rail/RailML/schemas/2013";
        root["soapenv:Envelope"]["@_xmlns:ns2"] = "http://purl.org/dc/elements/1.1/";
        root["soapenv:Envelope"]["@_xmlns:ivu"] = "http://www.ivu.de/2012";
        return root;
    },
    addSoapHeaderAndBody: function (json) {
        json["soapenv:Envelope"]["soapenv:Header"] = "";
        json["soapenv:Envelope"]["soapenv:Body"] = {};
    }
    // ,
    // addimportTripRequest: function (json) {
    //     let importTripRequest = json["soapenv:Envelope"]["soapenv:Body"]["ns:importTripRequest"]  = {};
    //     importTripRequest["@_planningLevel"] = "DISPATCH";
    //     importTripRequest["@_overrideHandshakeVersion"] = "true";
    // },
    // addrailml: function (json) {
    //     let railml = json["soapenv:Envelope"]["soapenv:Body"]["ns:importTripRequest"]["ns1:railml"] = {};
    //     railml["@_version"] = "2.0";
    // },
    // addinfrastructure: function (src,json){
    //     let infrastructure = json["soapenv:Envelope"]["soapenv:Body"]["ns:importTripRequest"]["ns1:railml"]["ns1:infrastructure"] = {};

    //     infrastructure["@_id"] = "infra1";
    //     let operationControlPoints = infrastructure["ns1:operationControlPoints"] ={};
        
    //     //Get all Stationpassage nodes
    //     if (src.MadsLightResponse.OprangeringDag) {

    //         let Stationpassage = src.MadsLightResponse.OprangeringDag.Stationpassage;
            
    //         // Loop all Stationpassage          
    //         console.log('Request contains ' + Stationpassage.length + ' number of station passages.');
            
    //         let ocps = operationControlPoints["ns1:ocp"] = [];
            
    //         let i = 1;
    //         Stationpassage.forEach(item => {
    //             let paddedNumber = this.padzeros(i++,7);
    //             let ocp = {
    //                 ["@_id"] : "ocp".concat(paddedNumber),
    //                 ["@_code"] : item.Station["@_Forkortelse"].concat(".", item.Station["@_Landekode"] )
    //             };

    //             ocps.push(ocp);
    //         });         
            
    //     }
    //     else
    //     {
    //         console.log("No OprangeringDag");
    //     }


    // },
    // addrollingstock: function (src,json){
    //     let rollingstock = json["soapenv:Envelope"]["soapenv:Body"]["ns:importTripRequest"]["ns1:railml"]["ns1:rollingstock"] = {};
    //     rollingstock["@_id"] = "roll1";

    //     let rollingstockformations = rollingstock["ns1:formations"] = {}
        
    //     //Get all Stationpassage nodes
    //     if (src.MadsLightResponse.OprangeringDag) {

    //         let VognturDelstraekning = src.MadsLightResponse.OprangeringDag.OprangeringDelstraekning.VognturDelstraekning;
            
    //         // Loop all Stationpassage          
    //         console.log('Request contains ' + VognturDelstraekning.length + ' number of vehicles.');
            
    //         let formations = rollingstockformations["ns1:formation"] = [];
            
    //         let i = 1;
    //         VognturDelstraekning.forEach(item => {
    //             let paddedNumber = this.padzeros(i++,5);
    //             let formation = {
    //                 ["@_id"]: "f".concat(paddedNumber),
    //                 ["@_name"] : item.Vogntur["@_Litra"]
    //             };

    //             formations.push(formation);
    //         });
    //     }

    // },
    // addtimetable:function(json){
    //     let timetable = json["soapenv:Envelope"]["soapenv:Body"]["ns:importTripRequest"]["ns1:railml"]["ns1:timetable"]  = {};
    //     timetable["@_id"] = "time1";
    // },
    // addoperatingPeriods:function(src, json){
    //     let operatingPeriods = json["soapenv:Envelope"]["soapenv:Body"]["ns:importTripRequest"]["ns1:railml"]["ns1:timetable"]["ns1:operatingPeriods"]  = {};
        
    //     operatingPeriods["ns1:operatingPeriod"] = {
    //         ["@_id"] : "op0001",
    //         ["@_name"] : "1",
    //         ["@_description"] : "one_day",
    //         ["@_startDate"] : src.MadsLightResponse.OprangeringDag.TogDag["@_Dato"],
    //         ["@_bitMask"] : "1"
    //     }
        
    // },
    // addcategories:function(src, json){
    //     let categories = json["soapenv:Envelope"]["soapenv:Body"]["ns:importTripRequest"]["ns1:railml"]["ns1:timetable"]["ns1:categories"]  = {};
        
    //     let ivuTrainCategory = this.gettraincategory(src.MadsLightResponse.OprangeringDag.TogDag["@_Kategori"]);

    //     categories["ns1:category"] = {
    //         ["@_id"] : "c0001",
    //         ["@_name"] : ivuTrainCategory
    //     }
        
    // },
    // gettraincategory:function(madscategory)
    // {
           
    //     let ivuTrainCategory;
    //     //TogDag.Kategori ØP, ØD, ØK, ØF -> (RST = Mads). REG = IVU
    //     if (madscategory === "ØP" || madscategory === "ØD" || madscategory === "ØK" || madscategory === "ØF") {
    //         ivuTrainCategory = "REG"; // REG to indicate that train carries passengers
    //     }
    //     //TogDag.Kategori ØM -> TJT     
    //     else if (madscategory === "ØM") {
    //         ivuTrainCategory = "TJT"; // TJT to indicate that train carries no passengers
    //     }
    //     else {
    //         ivuTrainCategory = madscategory; //other
    //     }
    //     return ivuTrainCategory;
    // },
    // addtrainParts:function(src, json){
    //     let trainParts = json["soapenv:Envelope"]["soapenv:Body"]["ns:importTripRequest"]["ns1:railml"]["ns1:timetable"]["ns1:trainParts"]  = {};
                
    // },
    // addtrain:function(src, json){
    //     let trains = json["soapenv:Envelope"]["soapenv:Body"]["ns:importTripRequest"]["ns1:railml"]["ns1:timetable"]["ns1:trains"]  = {};

    //     trains["ns1:train"] = {
    //         ["@_id"] : "t000001",
    //         ["@_type"] : "operational",
    //         ["@_trainNumber"] : src.MadsLightResponse.OprangeringDag.TogDag["@_Tognummer"],
    //         ["ns1:trainPartSequence"]:{
    //             ["@_sequence"] : "1",
    //             ["@_ivuInfrastructureTrainNumber"] : src.MadsLightResponse.OprangeringDag.TogDag["@_Tognummer"]
    //         }
    //     }
                
    // },
    // padzeros:function(num, size) {
    //     var s = "000000000" + num;
    //     return s.substr(s.length-size);
    // }
}

