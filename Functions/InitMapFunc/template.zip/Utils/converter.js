const fs = require('fs');
const json2xmlParser = require('fast-xml-parser');
const xml2jsonParser = require("fast-xml-parser").j2xParser;
var locationMapping;
var tractionTypes;

module.exports = {
    xml2json: function (xmlInput) {
        const xmloptions = {
            attributeNamePrefix: "@_",
            //attrNodeName: false,
            //textNodeName : "#text",
            ignoreAttributes: false,
            ignoreNameSpace: true,
        };
        return json2xmlParser.parse(xmlInput, xmloptions);
    },
    json2xml: function (jsonInput) {
        const jsonOptions = {
            attributeNamePrefix: "@_",
            //attrNodeName: false,
            //textNodeName : "#text",
            ignoreAttributes: false,
            ignoreNameSpace: false,
            format: true, //Pretty print output
            //indentBy: "  ",
            //supressEmptyNode: false,
        };
        const parserJson = new xml2jsonParser(jsonOptions);
        return parserJson.parse(jsonInput, jsonOptions);
    }
	//Lookup values can be placed here with corresponding.xml files
	// ,
    // locationMappingXml2json: function () {
        // if (!locationMapping) {
            // const xmlInput = fs.readFileSync('./Utils/LocationMapping.xml', 'utf8');
            // const xmloptions = {
                // attributeNamePrefix: "@_",
                // //attrNodeName: false,
                // //textNodeName : "#text",
                // ignoreAttributes: false,
                // ignoreNameSpace: true,
            // };
            // locationMapping = json2xmlParser.parse(xmlInput, xmloptions);
        // }
        // return locationMapping;
    // }
}