module.exports = {
    log: jest.fn()
};