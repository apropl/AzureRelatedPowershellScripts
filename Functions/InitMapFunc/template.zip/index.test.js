const fs = require('fs');
const httpFunction = require('./index');
const context = require('../testing/defaultContext')
const map = require('./map');
const converter = require("../Utils/converter");
const libxml = require('libxmljs');


function mapTest(inputFile, outputFile) {
    let xmlData = fs.readFileSync(inputFile, 'utf8');
    let jsonSrc = converter.xml2json(xmlData);
    let jsonDst = map.mapDocument(jsonSrc);
    
    expect(jsonDst).not.toBeUndefined();

    let xmlDst = converter.json2xml(jsonDst);
    fs.writeFileSync(outputFile, xmlDst);

    return { json: jsonDst, xml: xmlDst };
};

test('SimpleTestMapWithFile', async () => {
    let data = mapTest('./Transform/SampleFiles/sampletestfile.xml',
    './Transform/SampleFiles/sampletestfile.xml_tmpOutput.xml');
});


// test('Timetable year should be 2020', async () => {
//     let y = map.getTimeTableYear(new Date("2020-02-01"));
//     expect(y).toEqual("2020");
// });
// test('Timetable year should be 2020 still', async () => {
//     let y = map.getTimeTableYear(new Date("2020-12-12 23:00"));
//     expect(y).toEqual("2020");
// });
// test('Timetable year should be 2021', async () => {
//     let y = map.getTimeTableYear(new Date("2020-12-13"));
//     expect(y).toEqual("2021");
// });
// test('Timetable year should be 2022', async () => {
//     let y = map.getTimeTableYear(new Date("2021-12-12"));
//     expect(y).toEqual("2022");
// });

// test('CountryCode should be NO', async () => {

//     const locationMapping = converter.locationMappingXml2json();
//     let location = "XOSL";

//     let countryCode = locationMapping.PrimaryLocations.Primary_Location.find( function(item) {
//             return item.Free_Text == location;
//         }).Country_ISO_Code;
    
//     expect(countryCode).toEqual("NO");
// });
// test('CountryCode should be SE', async () => {

//     const locationMapping = converter.locationMappingXml2json();
//     let location = "CG";

//     let countryCode = locationMapping.PrimaryLocations.Primary_Location.find( function(item) {
//             return item.Free_Text == location;
//         }).Country_ISO_Code;
    
//     expect(countryCode).toEqual("SE");
// });


// function mapTest(inputFile, outputFile) {
//     let xmlData = fs.readFileSync(inputFile, 'utf8');
//     let jsonSrc = converter.xml2json(xmlData);
//     jsonSrc = jsonSrc.TrainReport_ws.TrainReport.Train;       
//     let jsonDst = map.mapTrain(jsonSrc);
    
//     expect(jsonDst).not.toBeUndefined();

//     let xmlDst = converter.json2xml(jsonDst);
//     fs.writeFileSync(outputFile, xmlDst);

//     let xsd = fs.readFileSync('./Transform/vognopptak.xsd', 'utf8');
//     let xsdDoc = libxml.parseXmlString(xsd);

//     let xml = fs.readFileSync(outputFile, 'utf8');
//     let xmlDoc = libxml.parseXmlString(xml);

//     let validationResult = xmlDoc.validate(xsdDoc);
//     if (xmlDoc.validationErrors.length > 0) {
//         console.log(xmlDoc.validationErrors);
//     }
//     expect(xmlDoc.validationErrors.length).toEqual(0);
//     expect(validationResult).toEqual(true);

//     return { json: jsonDst, xml: xmlDst };
// }

// test('Map and Validate Engine only travelling NO.OSL-CG', async () => {
//     let data = mapTest('./Transform/SampleFiles/Report_engineonly_mockup.xml',
//     './Transform/SampleFiles/Report_engineonly_mockup_tmpOutput.xml');

//     expect(data.json.TrainCompositionMessage.TransportOperationalIdentifiers.TimetableYear).toEqual("2020");
//     expect(data.json.TrainCompositionMessage.OperationalTrainNumber).toEqual("12345");
//     expect(data.json.TrainCompositionMessage.TrainCompositionJourneySection).toHaveLength(1);
//     expect(data.json.TrainCompositionMessage.TrainCompositionJourneySection[0].TrainRunningData.TrainRunningTechData.TrainType).toEqual("03");
//     expect(data.json.TrainCompositionMessage.TrainCompositionJourneySection[0].LocoIdent.TractionType).toEqual("Rc6");
//     expect(data.json.TrainCompositionMessage.TrainCompositionJourneySection[0].LocoIdent.TractionPositionInTrain).toBeUndefined();
//     expect(data.json.TrainCompositionMessage.TrainCompositionJourneySection[0].JourneySection.JourneySectionOrigin.CountryCodeISO).toEqual("NO");
//     expect(data.json.TrainCompositionMessage.TrainCompositionJourneySection[0].JourneySection.JourneySectionDestination.CountryCodeISO).toEqual("SE");
//     expect(data.json.TrainCompositionMessage.TrainCompositionJourneySection[0].WagonData).toBeUndefined();
// });

// test('Map and Validate X55 Engines with seats travelling NO.OSL-CG', async () => {
//     let data = mapTest('./Transform/SampleFiles/Report_engineswithseatsX55_mockup.xml',
//     './Transform/SampleFiles/Report_engineswithseatsX55_mockup_tmpOutput.xml');

//     expect(data.json.TrainCompositionMessage.TransportOperationalIdentifiers.TimetableYear).toEqual("2020");
//     expect(data.json.TrainCompositionMessage.OperationalTrainNumber).toEqual("591");
//     expect(data.json.TrainCompositionMessage.TrainCompositionJourneySection).toHaveLength(1);
//     expect(data.json.TrainCompositionMessage.TrainCompositionJourneySection[0].TrainRunningData.TrainRunningTechData.TrainType).toEqual("01");
//     expect(data.json.TrainCompositionMessage.TrainCompositionJourneySection[0].LocoIdent.TractionType).toEqual("X55");
//     expect(data.json.TrainCompositionMessage.TrainCompositionJourneySection[0].LocoIdent.TractionPositionInTrain).toBeUndefined();
//     expect(data.json.TrainCompositionMessage.TrainCompositionJourneySection[0].WagonData).toHaveLength(4);
//     expect(data.json.TrainCompositionMessage.TrainCompositionJourneySection[0].WagonData[0].WagonNumberFreight).toEqual("947445533518");
//     expect(data.json.TrainCompositionMessage.TrainCompositionJourneySection[0].WagonData[0].WagonTrainPosition).toEqual(1);
//     expect(data.json.TrainCompositionMessage.TrainCompositionJourneySection[0].WagonData[1].WagonNumberFreight).toEqual("947445535513");
//     expect(data.json.TrainCompositionMessage.TrainCompositionJourneySection[0].WagonData[1].WagonTrainPosition).toEqual(2);
//     expect(data.json.TrainCompositionMessage.TrainCompositionJourneySection[0].JourneySection.JourneySectionOrigin.CountryCodeISO).toEqual("NO");
//     expect(data.json.TrainCompositionMessage.TrainCompositionJourneySection[0].JourneySection.JourneySectionDestination.CountryCodeISO).toEqual("SE");

// });

// test('Map and Validate X55 mirrored Engines with seats travelling NO.OSL-CG', async () => {
//     let data = mapTest('./Transform/SampleFiles/Report_engineswithseatsX55mirrored_mockup.xml',
//     './Transform/SampleFiles/Report_engineswithseatsX55mirrored_mockup_tmpOutput.xml');

//     expect(data.json.TrainCompositionMessage.TransportOperationalIdentifiers.TimetableYear).toEqual("2020");
//     expect(data.json.TrainCompositionMessage.OperationalTrainNumber).toEqual("560");
//     expect(data.json.TrainCompositionMessage.TrainCompositionJourneySection).toHaveLength(1);
//     expect(data.json.TrainCompositionMessage.TrainCompositionJourneySection[0].TrainRunningData.TrainRunningTechData.TrainType).toEqual("01");
//     expect(data.json.TrainCompositionMessage.TrainCompositionJourneySection[0].LocoIdent.TractionType).toEqual("X55");
//     expect(data.json.TrainCompositionMessage.TrainCompositionJourneySection[0].LocoIdent.TractionPositionInTrain).toBeUndefined();
//     expect(data.json.TrainCompositionMessage.TrainCompositionJourneySection[0].WagonData).toHaveLength(4);
//     expect(data.json.TrainCompositionMessage.TrainCompositionJourneySection[0].WagonData[0].WagonNumberFreight).toEqual("947445537493");
//     expect(data.json.TrainCompositionMessage.TrainCompositionJourneySection[0].WagonData[0].WagonTrainPosition).toEqual(1);
//     expect(data.json.TrainCompositionMessage.TrainCompositionJourneySection[0].WagonData[1].WagonNumberFreight).toEqual("947445529490");
//     expect(data.json.TrainCompositionMessage.TrainCompositionJourneySection[0].WagonData[1].WagonTrainPosition).toEqual(2);
//     expect(data.json.TrainCompositionMessage.TrainCompositionJourneySection[0].JourneySection.JourneySectionOrigin.CountryCodeISO).toEqual("NO");
//     expect(data.json.TrainCompositionMessage.TrainCompositionJourneySection[0].JourneySection.JourneySectionDestination.CountryCodeISO).toEqual("SE");
// });

// test('Map and Validate RC6 travelling CG-NO.OSL', async () => {
//     let data = mapTest('./Transform/SampleFiles/Report_enginewagonsRC6_mockup.xml',
//     './Transform/SampleFiles/Report_enginewagonsRC6_mockup_tmpOutput.xml');

//     expect(data.json.TrainCompositionMessage.TransportOperationalIdentifiers.TimetableYear).toEqual("2020");
//     expect(data.json.TrainCompositionMessage.OperationalTrainNumber).toEqual("613");
//     expect(data.json.TrainCompositionMessage.TrainCompositionJourneySection).toHaveLength(1);
//     expect(data.json.TrainCompositionMessage.TrainCompositionJourneySection[0].TrainRunningData.TrainRunningTechData.TrainType).toEqual("01");
//     expect(data.json.TrainCompositionMessage.TrainCompositionJourneySection[0].LocoIdent.TractionType).toEqual("Rc6");
//     expect(data.json.TrainCompositionMessage.TrainCompositionJourneySection[0].LocoIdent.TractionPositionInTrain).toBeUndefined();
//     expect(data.json.TrainCompositionMessage.TrainCompositionJourneySection[0].WagonData).toHaveLength(4);
//     expect(data.json.TrainCompositionMessage.TrainCompositionJourneySection[0].WagonData[0].WagonNumberFreight).toEqual("507439732375");
//     expect(data.json.TrainCompositionMessage.TrainCompositionJourneySection[0].WagonData[0].WagonTrainPosition).toEqual(1);
//     expect(data.json.TrainCompositionMessage.TrainCompositionJourneySection[0].WagonData[1].WagonNumberFreight).toEqual("507422733927");
//     expect(data.json.TrainCompositionMessage.TrainCompositionJourneySection[0].WagonData[1].WagonTrainPosition).toEqual(2);
//     expect(data.json.TrainCompositionMessage.TrainCompositionJourneySection[0].JourneySection.JourneySectionOrigin.CountryCodeISO).toEqual("SE");
//     expect(data.json.TrainCompositionMessage.TrainCompositionJourneySection[0].JourneySection.JourneySectionDestination.CountryCodeISO).toEqual("NO");
// });

// test('Map and Validate X2 engine front travelling CG-NO.OSL', async () => {
//     let data = mapTest('./Transform/SampleFiles/Report_enginewagonsX2_mockup.xml',
//     './Transform/SampleFiles/Report_enginewagonsX2_mockup_tmpOutput.xml');

//     expect(data.json.TrainCompositionMessage.TransportOperationalIdentifiers.TimetableYear).toEqual("2020");
//     expect(data.json.TrainCompositionMessage.TrainCompositionJourneySection).toHaveLength(1);
//     expect(data.json.TrainCompositionMessage.TrainCompositionJourneySection[0].TrainRunningData.TrainRunningTechData.TrainType).toEqual("01");
//     expect(data.json.TrainCompositionMessage.TrainCompositionJourneySection[0].LocoIdent.TractionType).toEqual("X2");
//     expect(data.json.TrainCompositionMessage.TrainCompositionJourneySection[0].LocoIdent.TractionPositionInTrain).toBeUndefined();
//     expect(data.json.TrainCompositionMessage.TrainCompositionJourneySection[0].WagonData).toHaveLength(6);
//     expect(data.json.TrainCompositionMessage.TrainCompositionJourneySection[0].WagonData[0].WagonNumberFreight).toEqual("937430229180");
//     expect(data.json.TrainCompositionMessage.TrainCompositionJourneySection[0].WagonData[0].WagonTrainPosition).toEqual(1);
//     expect(data.json.TrainCompositionMessage.TrainCompositionJourneySection[0].WagonData[5].WagonNumberFreight).toEqual("937430225378");
//     expect(data.json.TrainCompositionMessage.TrainCompositionJourneySection[0].WagonData[5].WagonTrainPosition).toEqual(6);
//     expect(data.json.TrainCompositionMessage.TrainCompositionJourneySection[0].JourneySection.JourneySectionOrigin.CountryCodeISO).toEqual("SE");
//     expect(data.json.TrainCompositionMessage.TrainCompositionJourneySection[0].JourneySection.JourneySectionDestination.CountryCodeISO).toEqual("NO");
// });

// test('Map and Validate X2 engine back travelling NO.OSL-CG', async () => {
//     let data = mapTest('./Transform/SampleFiles/Report_wagonsengineX2_mockup.xml',
//     './Transform/SampleFiles/Report_wagonsengineX2_mockup_tmpOutput.xml');

//     expect(data.json.TrainCompositionMessage.TransportOperationalIdentifiers.TimetableYear).toEqual("2020");
//     expect(data.json.TrainCompositionMessage.TrainCompositionJourneySection).toHaveLength(1);
//     expect(data.json.TrainCompositionMessage.TrainCompositionJourneySection[0].TrainRunningData.TrainRunningTechData.TrainType).toEqual("01");
//     expect(data.json.TrainCompositionMessage.TrainCompositionJourneySection[0].LocoIdent.TractionType).toEqual("X2");
//     expect(data.json.TrainCompositionMessage.TrainCompositionJourneySection[0].LocoIdent.TractionPositionInTrain).toEqual(6);
//     expect(data.json.TrainCompositionMessage.TrainCompositionJourneySection[0].WagonData).toHaveLength(6);
//     expect(data.json.TrainCompositionMessage.TrainCompositionJourneySection[0].WagonData[0].WagonNumberFreight).toEqual("937430225022");
//     expect(data.json.TrainCompositionMessage.TrainCompositionJourneySection[0].WagonData[0].WagonTrainPosition).toEqual(1);
//     expect(data.json.TrainCompositionMessage.TrainCompositionJourneySection[0].WagonData[5].WagonNumberFreight).toEqual("937430228869");
//     expect(data.json.TrainCompositionMessage.TrainCompositionJourneySection[0].WagonData[5].WagonTrainPosition).toEqual(6);
//     expect(data.json.TrainCompositionMessage.TrainCompositionJourneySection[0].JourneySection.JourneySectionOrigin.CountryCodeISO).toEqual("NO");
//     expect(data.json.TrainCompositionMessage.TrainCompositionJourneySection[0].JourneySection.JourneySectionDestination.CountryCodeISO).toEqual("SE");
// });


// test('Map and Validate RC6 travelling CG-NO.OSL with change in composition NO.SKA', async () => {
//     let data = mapTest('./Transform/SampleFiles/Report_enginewagonsRC6_2compositions_mockup.xml',
//     './Transform/SampleFiles/Report_enginewagonsRC6_2compositions_mockup_tmpOutput.xml');

//     expect(data.json.TrainCompositionMessage.TransportOperationalIdentifiers.TimetableYear).toEqual("2020");
//     expect(data.json.TrainCompositionMessage.TrainCompositionJourneySection).toHaveLength(2);

//     expect(data.json.TrainCompositionMessage.TrainCompositionJourneySection[0].TrainRunningData.TrainRunningTechData.TrainType).toEqual("01");
//     expect(data.json.TrainCompositionMessage.TrainCompositionJourneySection[0].LocoIdent.TractionType).toEqual("Rc6");
//     expect(data.json.TrainCompositionMessage.TrainCompositionJourneySection[0].LocoIdent.TractionPositionInTrain).toBeUndefined();
//     expect(data.json.TrainCompositionMessage.TrainCompositionJourneySection[0].WagonData).toHaveLength(4);
//     expect(data.json.TrainCompositionMessage.TrainCompositionJourneySection[0].WagonData[0].WagonNumberFreight).toEqual("507439732375");
//     expect(data.json.TrainCompositionMessage.TrainCompositionJourneySection[0].WagonData[0].WagonTrainPosition).toEqual(1);
//     expect(data.json.TrainCompositionMessage.TrainCompositionJourneySection[0].WagonData[2].WagonNumberFreight).toEqual("507485733012");
//     expect(data.json.TrainCompositionMessage.TrainCompositionJourneySection[0].WagonData[2].WagonTrainPosition).toEqual(3);
//     expect(data.json.TrainCompositionMessage.TrainCompositionJourneySection[0].JourneySection.ResponsibilityActualSection.ResponsibleIM).toEqual("0074"); // TrV
//     expect(data.json.TrainCompositionMessage.TrainCompositionJourneySection[0].JourneySection.ResponsibilityNextSection.ResponsibleIM).toEqual("0076"); // BaneNOR
//     expect(data.json.TrainCompositionMessage.TrainCompositionJourneySection[0].JourneySection.JourneySectionOrigin.CountryCodeISO).toEqual("SE");
//     expect(data.json.TrainCompositionMessage.TrainCompositionJourneySection[0].JourneySection.JourneySectionDestination.CountryCodeISO).toEqual("NO");

//     expect(data.json.TrainCompositionMessage.TrainCompositionJourneySection[1].TrainRunningData.TrainRunningTechData.TrainType).toEqual("01");
//     expect(data.json.TrainCompositionMessage.TrainCompositionJourneySection[1].LocoIdent.TractionType).toEqual("Rc6");
//     expect(data.json.TrainCompositionMessage.TrainCompositionJourneySection[1].LocoIdent.TractionPositionInTrain).toBeUndefined();
//     expect(data.json.TrainCompositionMessage.TrainCompositionJourneySection[1].WagonData).toHaveLength(3);
//     expect(data.json.TrainCompositionMessage.TrainCompositionJourneySection[1].JourneySection.ResponsibilityActualSection.ResponsibleIM).toEqual("0076"); // Bane NOR
//     expect(data.json.TrainCompositionMessage.TrainCompositionJourneySection[1].JourneySection.ResponsibilityNextSection.ResponsibleIM).toEqual("0076"); // Bane NOR
//     expect(data.json.TrainCompositionMessage.TrainCompositionJourneySection[1].JourneySection.JourneySectionOrigin.CountryCodeISO).toEqual("NO");
//     expect(data.json.TrainCompositionMessage.TrainCompositionJourneySection[1].JourneySection.JourneySectionDestination.CountryCodeISO).toEqual("NO");
// });


// test('Map and Validate RC6 travelling NO.OSL-CG with change in composition NO.KVG', async () => {
//     let data = mapTest('./Transform/SampleFiles/Report_enginewagonsRC6_2compositions_otherdirection_mockup.xml',
//     './Transform/SampleFiles/Report_enginewagonsRC6_2compositions_otherdirection_mockup_tmpOutput.xml');

//     expect(data.json.TrainCompositionMessage.TransportOperationalIdentifiers.TimetableYear).toEqual("2020");
//     expect(data.json.TrainCompositionMessage.TrainCompositionJourneySection).toHaveLength(2);

//     expect(data.json.TrainCompositionMessage.TrainCompositionJourneySection[0].TrainRunningData.TrainRunningTechData.TrainType).toEqual("01");
//     expect(data.json.TrainCompositionMessage.TrainCompositionJourneySection[0].LocoIdent.TractionType).toEqual("Rc6");
//     expect(data.json.TrainCompositionMessage.TrainCompositionJourneySection[0].LocoIdent.TractionPositionInTrain).toBeUndefined();
//     expect(data.json.TrainCompositionMessage.TrainCompositionJourneySection[0].WagonData).toHaveLength(4);
//     expect(data.json.TrainCompositionMessage.TrainCompositionJourneySection[0].JourneySection.ResponsibilityActualSection.ResponsibleIM).toEqual("0076"); // BaneNOR
//     expect(data.json.TrainCompositionMessage.TrainCompositionJourneySection[0].JourneySection.JourneySectionOrigin.CountryCodeISO).toEqual("NO");
//     expect(data.json.TrainCompositionMessage.TrainCompositionJourneySection[0].JourneySection.JourneySectionOrigin.PrimaryLocationName).toEqual("Oslo S");
//     expect(data.json.TrainCompositionMessage.TrainCompositionJourneySection[0].JourneySection.ResponsibilityNextSection.ResponsibleIM).toEqual("0076"); // BaneNOR
//     expect(data.json.TrainCompositionMessage.TrainCompositionJourneySection[0].JourneySection.JourneySectionDestination.CountryCodeISO).toEqual("NO");
//     expect(data.json.TrainCompositionMessage.TrainCompositionJourneySection[0].JourneySection.JourneySectionDestination.PrimaryLocationName).toEqual("Kongsvinger");

//     expect(data.json.TrainCompositionMessage.TrainCompositionJourneySection[1].TrainRunningData.TrainRunningTechData.TrainType).toEqual("01");
//     expect(data.json.TrainCompositionMessage.TrainCompositionJourneySection[1].LocoIdent.TractionType).toEqual("Rc6");
//     expect(data.json.TrainCompositionMessage.TrainCompositionJourneySection[1].LocoIdent.TractionPositionInTrain).toBeUndefined();
//     expect(data.json.TrainCompositionMessage.TrainCompositionJourneySection[1].WagonData).toHaveLength(3);
//     expect(data.json.TrainCompositionMessage.TrainCompositionJourneySection[1].JourneySection.ResponsibilityActualSection.ResponsibleIM).toEqual("0076"); // BaneNOR
//     expect(data.json.TrainCompositionMessage.TrainCompositionJourneySection[1].JourneySection.JourneySectionOrigin.CountryCodeISO).toEqual("NO");
//     expect(data.json.TrainCompositionMessage.TrainCompositionJourneySection[1].JourneySection.JourneySectionOrigin.PrimaryLocationName).toEqual("Kongsvinger");
//     expect(data.json.TrainCompositionMessage.TrainCompositionJourneySection[1].JourneySection.ResponsibilityNextSection.ResponsibleIM).toEqual("0074"); // Trv
//     expect(data.json.TrainCompositionMessage.TrainCompositionJourneySection[1].JourneySection.JourneySectionDestination.CountryCodeISO).toEqual("SE");
//     expect(data.json.TrainCompositionMessage.TrainCompositionJourneySection[1].JourneySection.JourneySectionDestination.PrimaryLocationName).toEqual("Charlottenberg");
// });


// test('Http trigger Transform rpsopera_08_33 many swedish one norwegian', async () => {

//     let xmlData = fs.readFileSync('./Transform/SampleFiles/rpsopera_08_33.xml', 'utf8');
    
//     const request = {
//         body: xmlData
//     };

//     await httpFunction(context, request);

//     // let i = 1;
//     // context.res.body.forEach(element => {
//     //     fs.writeFileSync('./Transform/SampleFiles/rpsopera_08_33_result' + i++ + '.xml', element);
//     // });
    
//     expect(context.res.body).not.toBeUndefined();
//     expect(context.res.body.length).toBe(1);

// });


// test('Http trigger Transform Report_ALL mix of all', async () => {

//     let xmlData = fs.readFileSync('./Transform/SampleFiles/Report_ALL_mockup.xml', 'utf8');
    
//     const request = {
//         body: xmlData
//     };

//     await httpFunction(context, request);

//     // let i = 1;
//     // context.res.body.forEach(element => {
//     //     fs.writeFileSync('./Transform/SampleFiles/rpsopera_08_33_result' + i++ + '.xml', element);
//     // });
    
//     expect(context.res.body).not.toBeUndefined();
//     expect(context.res.body.length).toBe(8);
// });