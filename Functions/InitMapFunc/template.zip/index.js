const converter = require("../Utils/converter");
const map = require("./map");

module.exports = async function (context, req) {
    context.log('JavaScript HTTP trigger function processed a request.');

    if (req.body) {

        let jsonSrc = converter.xml2json(req.body);

        let jsonDst = map.mapDocument(jsonSrc);
        let xmlDst = converter.json2xml(jsonDst);

        context.res = {
            status: 200,
            body: xmlDst
        };
    }
    else {
        context.res = {
            status: 400,
            body: "Message has en empty body."
        };
    }
};