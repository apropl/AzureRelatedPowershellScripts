﻿using System;
using System.Collections.Generic;
using System.Text;

namespace FunctionAppNameNS.Test
{
  public enum LoggerTypes
  {
    Null,
    List
  }
}
