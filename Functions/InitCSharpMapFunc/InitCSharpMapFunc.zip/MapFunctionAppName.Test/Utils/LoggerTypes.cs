﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Function_App_Name_NS.Test
{
  public enum LoggerTypes
  {
    Null,
    List
  }
}
